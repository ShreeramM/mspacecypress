export class loginPageconstants{
title = 'Masterpiece Solutions'
cardtitle='Welcome to MPM! 👋'
companyerror='Company is required'
usernameerror = 'Username is required'
passworderror='Password is required'
}
export default new loginPageconstants