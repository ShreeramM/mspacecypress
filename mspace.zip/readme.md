Cypress Installation -
======================================
1. Install VS Code
2. Create a Folder under C drive under Users with logical name
3. Create src Folder
4. Open File explorer under src folder and run command npm init
5. Follow the instructions and create package.json File
6. Opne VS Code where package.json is located
7. Run the command npm install cypress --save-dev and wait for cypress to get installed
8. Run the command npx cypress open
9. Follow the instructions in cypress Test Runner to create the Folder structure
10. Running cypress in headful mode - 
	a. npm run cypress:open

Cucumber Installation - 
======================================
1. Run command in terminal - npm install --save-dev cypress-cucumber-preprocessor
2. Add below changes under src > Cypress
	a. create plugins folder > create index.js File	
	b. Add below code - 
		const cucumber = require('cypress-cucumber-preprocessor').default;
		module.exports = (on, config) => {
		on('file:preprocessor', cucumber());
		};
3. Under package.json file add below settings - 
	"cypress-cucumber-preprocessor": {
    "stepDefinitions": "./cypress/integration/stepDefinitions/"
  }
4. Under cypress.config.js add - specPattern: 'cypress/integration/features/*.{feature,features}',
5. Install Cucumber gherkin plugin from VS Code Extensions Tab
6. Install cucumber-gotostep plugin from VS Code Extensions Tab
	a. Configure via VS Code - File > Preferences > Settings > Cucumber gotostep under SrcPath specify for User Tab - cypress/integration/stepDefinitions
	b. For Workspace Tab - Scr Path specify - cypress/integration/stepDefinitions settings.json file will be created under .vscode folder
7. Change the path under .vscode > settings.json "cucumberautocomplete.steps": "cypress/integration/stepDefinitions/*.js"
8. Check the linking from feature file by clicking ctrl + any step it will redirect to stepdefinition.js file

Application URL & Credentials
=================================
http://104.237.6.240/
Company - testing
User - mijay
Pwd - 123456